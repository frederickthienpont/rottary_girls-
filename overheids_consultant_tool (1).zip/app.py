from flask import Flask, render_template, request, redirect, url_for, flash
import csv
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'

DATA_FILE = 'data/transactions.csv'
CONSULTANTS_FILE = 'data/consultants.csv'

def ensure_files():
    os.makedirs('data', exist_ok=True)
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Naam', 'Bedrag', 'Status'])
    if not os.path.exists(CONSULTANTS_FILE):
        with open(CONSULTANTS_FILE, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Naam', 'IBAN'])

@app.route('/')
def index():
    with open(DATA_FILE, newline='') as file:
        reader = list(csv.reader(file))[1:]
    return render_template('index.html', transactions=reader)

@app.route('/uitbetalen', methods=['POST'])
def uitbetalen():
    naam = request.form['naam']
    bedrag = request.form['bedrag']
    status = "Verzonden"
    with open(DATA_FILE, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([naam, bedrag, status])
    flash('Uitbetaling geregistreerd!', 'success')
    return redirect(url_for('index'))

@app.route('/consultants')
def consultants():
    with open(CONSULTANTS_FILE, newline='') as file:
        reader = list(csv.reader(file))[1:]
    return render_template('consultants.html', consultants=reader)

@app.route('/add_consultant', methods=['POST'])
def add_consultant():
    naam = request.form['naam']
    iban = request.form['iban']
    with open(CONSULTANTS_FILE, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([naam, iban])
    flash('Consultant toegevoegd!', 'success')
    return redirect(url_for('consultants'))

if __name__ == '__main__':
    ensure_files()
    app.run(debug=True)